<html>
<head>
	<title></title>
</head>
<body>
	<form action="<?php echo e(route('changePassword')); ?>" method="POST">
		Password lama : <input type="password" name="oldPassword"> <?php echo e($errors->first('oldPassword')); ?>

		<br><br>
		Password baru: <input type="password" name="newPassword"> <?php echo e($errors->first('newPassword')); ?>

		<br><br>
		confirm password baru: <input type="password" name="newPassword_confirmation">
		<br><br>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<input type="submit">
	</form>
</body>
</html>
