<html>
<head>
    <title></title>
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>
    <meta property="og:url"           content="http://www.ngebuat.com/daeun/showProduct/<?php echo e($product->id); ?>" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="<?php echo e($product->nama); ?>" />
    <meta property="og:description"   content="See my new product" />
    <meta property="og:image"         content="<?php echo e($product->picture); ?>}" />
</head>
<body>
    <script>
    function like(){
        var token = "<?php echo e(csrf_token()); ?>";
        var url = '/like';
        $.post(url, {id: "<?php echo e($product->id); ?>", _token: token}, function(data){
            if(data["status"]!="failed"){
                if(data["button"]=="liked"){
                    data["button"]="dislike";
                }
                $("#like").html(data["button"]);
                $("#jml_like").html(data["value"]);
               console.log(data);
           }
           else{
                window.location = "/login";
           }
        });
    }
    </script>
    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

    <div class="fb-share-button" data-href="http://www.ngebuat.com/daeun/showProduct/&#123;&#123;$product-&gt;id&#125;&#125;" data-layout="button" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.ngebuat.com%2Fdaeun%2FshowProduct%2F%257B%257B%24product-%3Eid%257D%257D&amp;src=sdkpreparse">Share</a></div>
    <?php if($like==NULL): ?>
    <?php else: ?>
        <?php if($like=="liked"): ?>
            <?php
                $like="dislike"
            ?>
        <?php endif; ?>
        <button onclick="like()"><span id="like"><?php echo e($like); ?></span></button><br><br>
    <?php endif; ?>
    TENTANG CREATOR<br><br>
    <?php echo e($pembuat_produk->username); ?> <br><br>
    <?php echo e($pembuat_produk->biodata); ?> <br><br>
    -------------------------------------------------------------
    <br><br>
    KARYA LAINNYA<br><br>
    <?php $__currentLoopData = $product_other; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pOther): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Nama : <?php echo e($pOther->nama); ?>

        <br><br>
        Pembuat : <?php echo e($pOther->username_pembuat); ?>

        <br><br>
        <?php if($pOther->penghargaan==0): ?>
            Tidak ada Penghargaan <br><br>
        <?php else: ?>
            Ada penghargaan <br><br>
        <?php endif; ?>
        <img src="../../<?php echo e($pOther->picture); ?>" height=200 width=200><br><br>
        <a href="../../showProduct/<?php echo e($pOther->id); ?>">link</a>
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    -------------------------------------------------------------
    <br><br>
    KARYA SERUPA<br><br>
    <?php $__currentLoopData = $product_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pRelated): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Nama : <?php echo e($pRelated->nama_produk); ?>

        <br><br>
        Pembuat : <?php echo e($pRelated->username_pembuat_produk); ?>

        <br><br>
        <?php if($pRelated->penghargaan_produk==0): ?>
            Tidak ada Penghargaan <br><br>
        <?php else: ?>
            Ada penghargaan <br><br>
        <?php endif; ?>
        <img src="../../<?php echo e($pRelated->picture_produk); ?>" height=200 width=200><br><br>
        <a href="../../showProduct/<?php echo e($pRelated->product_id); ?>">link</a>
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    -------------------------------------------------------------
    <br><br>
    <?php if($product->isVerified==0): ?>
        UNVERIFIED <br><br>
    <?php else: ?>
        VERIFIED <br><br>
    <?php endif; ?>
    <img src="../<?php echo e($product->picture); ?>" height=200 width=200>
    <br><br>
    Nama : <?php echo e($product->nama); ?>

    <br><br>
    Kesulitan : <?php echo e($product->kesulitan); ?>

    <br><br>
    Harga : <?php echo e($product->harga); ?>

    <br><br>
    Kategori : <?php echo e($product->kategori); ?>

    <br><br>
    Penjelasan : <?php echo e($product->penjelasan); ?>

    <br><br>
    Likes : <span id="jml_like"><?php echo e($product->likes); ?></span>
    <br><br>
    Views : <?php echo e($product->views); ?>

    <br><br>
    <b>LABEL</b> : <br><br>
    <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($label); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    <b>Alat</b> : <br><br>
    <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($tool->nama); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    <b>Bahan</b> : <br><br>
    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($material->nama); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    <b>Langkah</b> : <br><br>
    <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Judul : <?php echo e($step->judul); ?>

        <br><br>
        Penjelasan : <?php echo e($step->penjelasan); ?>

        <br><br>
        <?php
            $arr = $productCtrl->getStepPictures($step->id);
        ?>
        <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pict): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($pict!=null): ?>
                Gambar : <img src="../<?php echo e($pict->picture); ?>" height=200 width=200>
                <br><br>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        --------------------------------------------------------------------
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    <b>KOMENTAR</b> <br><br>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($comment->username); ?> <br>
        <?php
            $subDate = $productCtrl->substractDate($comment->created_at);
        ?>
        <?php echo e($subDate); ?><br><br>
        <?php echo e($comment->body); ?> <br>
        <?php if($comment->picture!=NULL): ?>
            <img src="../<?php echo e($comment->picture); ?>" height=200 width=200>
        <?php endif; ?>
        <br>
        -----------------------------------
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    <form action="<?php echo e(route('addComment')); ?>" method="POST" enctype="multipart/form-data">
        <input size=100 type="text" name="BodyCmt"><br><br>
        <input type="file" name="PictureCmt"><br><br>
        <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
        <input type="submit">
    </form>
</body>
</html>
