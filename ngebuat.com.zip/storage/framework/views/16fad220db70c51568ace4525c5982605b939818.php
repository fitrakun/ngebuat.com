<html>
<head>
	<title></title>
</head>
<body>
    TENTANG CREATOR<br><br>
    <?php echo e($pembuat_produk->username); ?> <br><br>
    <?php echo e($pembuat_produk->biodata); ?> <br><br>
    -------------------------------------------------------------
    <br><br>
    KARYA LAINNYA<br><br>
    <?php $__currentLoopData = $product_other; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pOther): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Nama : <?php echo e($pOther->nama); ?>

        <br><br>
        Pembuat : <?php echo e($pOther->username_pembuat); ?>

        <br><br>
        <?php if($pOther->penghargaan==0): ?>
            Tidak ada Penghargaan <br><br>
        <?php else: ?>
            Ada penghargaan <br><br>
        <?php endif; ?>
        <img src="../../<?php echo e($pOther->picture); ?>" height=200 width=200><br><br>
        <a href="../../showProduct/<?php echo e($pOther->id); ?>">link</a>
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    -------------------------------------------------------------
    <br><br>
    KARYA SERUPA<br><br>
    <?php $__currentLoopData = $product_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pRelated): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Nama : <?php echo e($pRelated->nama_produk); ?>

        <br><br>
        Pembuat : <?php echo e($pRelated->username_pembuat_produk); ?>

        <br><br>
        <?php if($pRelated->penghargaan_produk==0): ?>
            Tidak ada Penghargaan <br><br>
        <?php else: ?>
            Ada penghargaan <br><br>
        <?php endif; ?>
        <img src="../../<?php echo e($pRelated->picture_produk); ?>" height=200 width=200><br><br>
        <a href="../../showProduct/<?php echo e($pRelated->product_id); ?>">link</a>
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    -------------------------------------------------------------
    <br><br>
    <?php if($product->isVerified==0): ?>
        UNVERIFIED <br><br>
    <?php else: ?>
        VERIFIED <br><br>
    <?php endif; ?>
    <img src="../<?php echo e($product->picture); ?>" height=200 width=200>
    <br><br>
	Nama : <?php echo e($product->nama); ?>

	<br><br>
	Kesulitan : <?php echo e($product->kesulitan); ?>

	<br><br>
	Harga : <?php echo e($product->harga); ?>

	<br><br>
	Kategori : <?php echo e($product->kategori); ?>

	<br><br>
	Penjelasan : <?php echo e($product->penjelasan); ?>

	<br><br>
    Likes : <?php echo e($product->likes); ?>

    <br><br>
    Views : <?php echo e($product->views); ?>

    <br><br>
    LABEL : <br><br>
    <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($label); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
	Alat : <br><br>
	<?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($tool->nama); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    Bahan : <br><br>
    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo e($material->nama); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
    Langkah : <br><br>
    <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Judul : <?php echo e($step->judul); ?>

        <br><br>
        Penjelasan : <?php echo e($step->penjelasan); ?>

        <br><br>
        <?php
            $arr = $productCtrl->getStepPictures($step->id);
        ?>
        <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pict): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($pict!=null): ?>
                Gambar : <img src="../<?php echo e($pict->picture); ?>" height=200 width=200>
                <br><br>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        --------------------------------------------------------------------
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <br><br>
</body>
</html>
