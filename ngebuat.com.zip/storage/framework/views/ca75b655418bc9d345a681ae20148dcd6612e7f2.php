<html>
<head>
	<title></title>
</head>
<body>
	Search box :<br><br>
	<form action="<?php echo e(route('search')); ?>" method="POST" enctype="multipart/form-data">
		Kategori : <input type="text" name="Category"> <?php echo e($errors->first('Category')); ?>

		<br><br>
		Nama : <input type="text" name="Name"> <?php echo e($errors->first('Name')); ?>

		<br><br>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<input type="submit">
	</form>
	<br><br>
	<br><br>
	<?php if($search_result!=NULL): ?>
		search result : <br><br>
		<?php if($search_result!=NULL): ?>
			<?php $__currentLoopData = $search_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		        Nama : <?php echo e($product->nama_produk); ?>

				<br><br>
				Pembuat : <?php echo e($product->username_pembuat_produk); ?>

		        <br><br>
		        <?php if($product->penghargaan_produk==0): ?>
		        	Tidak ada Penghargaan <br><br>
		        <?php else: ?>
		        	Ada penghargaan <br><br>
		        <?php endif; ?>
		        <img src="../../<?php echo e($product->picture_produk); ?>" height=200 width=200><br><br>
				<a href="../../showProduct/<?php echo e($product->product_id); ?>">link</a>
				<br><br>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
	<?php endif; ?>
	<br><br>
	baru : <br><br>
	<?php $__currentLoopData = $product_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Nama : <?php echo e($product->nama); ?>

        <br><br>
        Pembuat : <?php echo e($product->username_pembuat); ?>

        <br><br>
        <?php if($product->penghargaan==0): ?>
        	Tidak ada Penghargaan <br><br>
        <?php else: ?>
        	Ada penghargaan <br><br>
        <?php endif; ?>
        <img src="../../<?php echo e($product->picture); ?>" height=200 width=200><br><br>
		<a href="../../showProduct/<?php echo e($product->id); ?>">link</a>
		<br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<br><br>
	popular : <br><br>
	<?php $__currentLoopData = $product_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        Nama : <?php echo e($product->nama); ?>

        <br><br>
        Pembuat : <?php echo e($product->username_pembuat); ?>

        <br><br>
        <?php if($product->penghargaan==0): ?>
        	Tidak ada Penghargaan <br><br>
        <?php else: ?>
        	Ada penghargaan <br><br>
        <?php endif; ?>
        <img src="../../<?php echo e($product->picture); ?>" height=200 width=200><br><br>
		<a href="../../showProduct/<?php echo e($product->id); ?>">link</a>
		<br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</body>
</html>
