<html>
<head>
	<title></title>
</head>
<body>
	<?php echo e($error); ?>

	<form action="<?php echo e(route('signin')); ?>" method="POST">
		Nama tampilan : <input type="text" name="Username"> <?php echo e($errors->first('Username')); ?>

		<br><br>
		password : <input type="password" name="Password"> <?php echo e($errors->first('Password')); ?>

		<br><br>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<input type="submit">
	</form>
</body>
</html>
