<html>
<head>
	<title></title>
</head>
<body>
	<form action="<?php echo e(route('edit')); ?>" method="POST" enctype="multipart/form-data">
		Nama : <input type="text" name="Name" value="<?php echo e($nama); ?>"> <?php echo e($errors->first('Name')); ?>

		<br><br>
		Gender : <input type="text" name="Sex" value="<?php echo e($gender); ?>"> <?php echo e($errors->first('Sex')); ?>

		<br><br>
		telp : <input type="text" name="Phone" value="<?php echo e($phone); ?>"> <?php echo e($errors->first('Phone')); ?>

		<br><br>
		website : <input type="text" name="Website" value="<?php echo e($website); ?>"> <?php echo e($errors->first('Website')); ?>

		<br><br>
		kota : <input type="text" name="City" value="<?php echo e($kota); ?>"> <?php echo e($errors->first('City')); ?>

		<br><br>
		kodepos : <input type="text" name="Postal" value="<?php echo e($kodepos); ?>"> <?php echo e($errors->first('Postal')); ?>

		<br><br>
		provinsi : <input type="text" name="Province" value="<?php echo e($provinsi); ?>"> <?php echo e($errors->first('Province')); ?>

		<br><br>
		negara : <input type="text" name="Country" value="<?php echo e($negara); ?>"> <?php echo e($errors->first('Country')); ?>

		<br><br>
		biodata : <input type="text" name="Bio" value="<?php echo e($biodata); ?>"> <?php echo e($errors->first('Bio')); ?>

		<br><br>
		tanggal lahir : <input type="text" name="Date" value="<?php echo e($date); ?>">
		bulan lahir : <input type="text" name="Month" value="<?php echo e($month); ?>">
		tahun lahir : <input type="text" name="Year" value="<?php echo e($year); ?>">
		<?php echo e($errors->first('Birthdate')); ?>

		<br><br>
		<img src="<?php echo e($picture); ?>" width=100 height=100>
		<br><br>
		Profile Picture : <input type="file" name="ProfPic">
		<br><br>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<input type="submit">
	</form>
</body>
</html>
