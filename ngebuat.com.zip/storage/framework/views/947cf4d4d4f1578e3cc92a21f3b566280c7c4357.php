<html>
<head>
	<title></title>
</head>
<body>
	<script>
		var countAlat = 1;
		var countBahan = 1;
		var countStep = 3;
	</script>
	<form action="<?php echo e(route('addProduct')); ?>" method="POST" enctype="multipart/form-data">
		Nama : <input type="text" name="Name"> <?php echo e($errors->first('Name')); ?>

		<br><br>
		Label : <input type="text" name="Label"> <?php echo e($errors->first('Label')); ?>

		<br><br>
		Tingkat Kesulitan : <input type="text" name="Level"> <?php echo e($errors->first('Level')); ?>

		<br><br>
		Perkiraan Harga : <input type="text" name="Price"> <?php echo e($errors->first('Price')); ?>

		<br><br>
		Kategori : <input type="text" name="Category"> <?php echo e($errors->first('Category')); ?>

		<br><br>
		Penjelasan Karya : <input type="text" name="Desc"> <?php echo e($errors->first('Desc')); ?>

		<br><br>
		Gambar : <input type="file" name="Picture"> <?php echo e($errors->first('Picture')); ?> 
		<br><br>
		<div id='alat'>
			Alat : <br>
			<input type="text" name="alat1"><br><br> <?php echo e($errors->first('alat1')); ?> 
		</div>
		<button type="button" onClick="addColumnAlat();">add kolom</button>
		<br><br>
		<div id='bahan'>
			Bahan : <br>
			<input type="text" name="bahan1"><br><br> <?php echo e($errors->first('bahan1')); ?> 
			
		</div>
		<button type="button" onClick="addColumnBahan();">add kolom</button>
		<br><br>
		Langkah : <br><br>
		<div id='langkah'>
			Judul : <input type="text" name="judulstep1"><br><br> <?php echo e($errors->first('judulstep1')); ?> 
			Deskripsi : <input type="text" name="descstep1"><br><br> <?php echo e($errors->first('descstep1')); ?> 
			Gambar 1: <input type="file" name="step1-1"> <?php echo e($errors->first('step1-1')); ?> <br><br>
			<!--Gambar 2: <input type="file" name="step1-2"> <?php echo e($errors->first('step1-2')); ?> <br><br>
			Gambar 3: <input type="file" name="step1-3"> <?php echo e($errors->first('step1-3')); ?> <br><br>-->
		</div>
		<!--<div id='langkah'>
			Judul : <input type="text" name="judulstep2"><br><br> <?php echo e($errors->first('judulstep1')); ?> 
			Deskripsi : <input type="text" name="descstep2"><br><br> <?php echo e($errors->first('descstep1')); ?> 
			Gambar 1: <input type="file" name="step2-1"> <?php echo e($errors->first('step1-1')); ?> <br><br>
			Gambar 2: <input type="file" name="step2-2"> <?php echo e($errors->first('step1-2')); ?> <br><br>
		</div>
		<div id='langkah'>
			Judul : <input type="text" name="judulstep3"><br><br> <?php echo e($errors->first('judulstep1')); ?> 
			Deskripsi : <input type="text" name="descstep3"><br><br> <?php echo e($errors->first('descstep1')); ?> 
			Gambar 1: <input type="file" name="step3-1"> <?php echo e($errors->first('step1-1')); ?> <br><br>
			Gambar 2: <input type="file" name="step3-2"> <?php echo e($errors->first('step1-2')); ?> <br><br>
			Gambar 3: <input type="file" name="step3-3"> <?php echo e($errors->first('step1-3')); ?> <br><br>
			Gambar 3: <input type="file" name="step3-4"> <?php echo e($errors->first('step1-3')); ?> <br><br>
		</div>-->
		<br>
		<button type="button" onClick="addColumnStep();">add kolom</button>
		<br><br>
		<input type="hidden" id="countAlat" name="countAlat" value='1'>
		<input type="hidden" id="countBahan" name="countBahan" value='1'>
		<input type="hidden" id="countStep" name="countStep" value='1'>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<input type="submit">
	</form>	
</body>
</html>

<script type="text/javascript">
	function addColumnAlat(){
		++countAlat;
		var newcontent = "<input type=\"text\" name=\"alat" + countAlat + "\"><br><br> <?php echo e($errors->first('alat" + countAlat + "')); ?>";
		document.getElementById('alat').innerHTML += newcontent;
		
		document.getElementById('countAlat').setAttribute('value', countAlat);
		return true;
	}

	function addColumnBahan(){
		++countBahan;
		var newcontent = "<input type=\"text\" name=\"bahan" + countBahan + "\"><br><br> <?php echo e($errors->first('bahan" + countBahan + "')); ?>";
		document.getElementById('bahan').innerHTML += newcontent;
		
		document.getElementById('countBahan').setAttribute('value', countBahan);
		return true;
	}

	function addColumnStep(){
		++countStep;
		var newcontent = "Judul : <input type=\"text\" name=\"judulstep" + countStep + "\"><br><br> <?php echo e($errors->first('judulstep" + countStep + "')); ?> Deskripsi : <input type=\"text\" name=\"descstep" + countStep + "\"><br><br> <?php echo e($errors->first('descstep" + countStep + "')); ?> Gambar : <input type=\"file\" name=\"step" + countStep + "\"> <?php echo e($errors->first('step" + countStep + "')); ?> <br><br>"
		document.getElementById('langkah').innerHTML += newcontent;
		
		document.getElementById('countStep').setAttribute('value', countStep);
		return true;
	}
</script>