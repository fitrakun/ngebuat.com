<html>
   <head>
      <title>Ajax Example</title>
      
      <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>
      
      <script>
         function test(){
            var token = "<?php echo e(csrf_token()); ?>";
            var url = '/pictura';
            $.post(url, {id: '3', _token: token}, function(data){
               console.log(data);
               alert(data["button"]);
            });
         }
      </script>
   </head>
   
   <body>
      <div id = 'msg'>This message will be replaced using Ajax. 
         Click the button to replace the message.</div>

      <button id="testo" onclick="test()">babix</button>
   </body>

</html>