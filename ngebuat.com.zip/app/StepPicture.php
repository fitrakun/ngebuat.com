<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StepPicture extends Model
{
    //
    protected $table = "stepPictures";

    public $timestamps = false;
}
