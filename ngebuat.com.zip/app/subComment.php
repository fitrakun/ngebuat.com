<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subComment extends Model
{
    //
    public $timestamps = false;

    protected $table = "subcomments";
}
