<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StepPicture extends Model
{
    //
    protected $table = "steppictures";

    public $timestamps = false;
}
